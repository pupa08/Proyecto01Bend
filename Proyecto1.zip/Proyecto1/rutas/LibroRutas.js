const express = require('express');
const router = express.Router();
const libroController = require('../controladores/LibroController');

// Rutas para operaciones CRUD de libros
router.post('/', libroController.crearLibro);
router.get('/', libroController.obtenerLibros);
router.get('/:id', libroController.obtenerLibroPorId);
router.put('/:id', libroController.actualizarLibro);
router.delete('/:id', libroController.eliminarLibro);

module.exports = router;
