const express = require('express');
const router = express.Router();
const pedidoController = require('../controladores/PedidoController');

// Rutas para operaciones CRUD de pedidos
router.post('/', pedidoController.crearPedido);
router.get('/', pedidoController.obtenerPedidos);
router.get('/:id', pedidoController.obtenerPedidoPorId);
router.put('/:id', pedidoController.actualizarPedido);
router.delete('/:id', pedidoController.eliminarPedido);

module.exports = router;
