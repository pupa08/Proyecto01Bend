const Libro = require('../modelos/Libro');

// Controlador para crear un nuevo libro
exports.crearLibro = async (req, res) => {
    try {
        const nuevoLibro = await Libro.create(req.body);
        res.status(201).json({ libro: nuevoLibro });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al crear libro', error: error.message });
    }
};

// Controlador para obtener todos los libros
exports.obtenerLibros = async (req, res) => {
    try {
        const libros = await Libro.find();
        res.status(200).json({ libros });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al obtener libros', error: error.message });
    }
};

// Controlador para obtener un libro por su ID
exports.obtenerLibroPorId = async (req, res) => {
    try {
        const libro = await Libro.findById(req.params.id);
        if (!libro) {
            return res.status(404).json({ mensaje: 'Libro no encontrado' });
        }
        res.status(200).json({ libro });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al obtener libro', error: error.message });
    }
};

// Controlador para actualizar un libro por su ID
exports.actualizarLibro = async (req, res) => {
    try {
        const libro = await Libro.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!libro) {
            return res.status(404).json({ mensaje: 'Libro no encontrado' });
        }
        res.status(200).json({ libro });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al actualizar libro', error: error.message });
    }
};

// Controlador para eliminar un libro por su ID
exports.eliminarLibro = async (req, res) => {
    try {
        const libro = await Libro.findByIdAndDelete(req.params.id);
        if (!libro) {
            return res.status(404).json({ mensaje: 'Libro no encontrado' });
        }
        res.status(200).json({ mensaje: 'Libro eliminado correctamente' });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al eliminar libro', error: error.message });
    }
};

// Otros controladores para operaciones CRUD adicionales...
