const Pedido = require('../modelos/Pedido');

// Controlador para crear un nuevo pedido
exports.crearPedido = async (req, res) => {
    try {
        const nuevoPedido = await Pedido.create(req.body);
        res.status(201).json({ pedido: nuevoPedido });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al crear pedido', error: error.message });
    }
};

// Controlador para obtener todos los pedidos
exports.obtenerPedidos = async (req, res) => {
    try {
        const pedidos = await Pedido.find();
        res.status(200).json({ pedidos });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al obtener pedidos', error: error.message });
    }
};

// Controlador para obtener un pedido por su ID
exports.obtenerPedidoPorId = async (req, res) => {
    try {
        const pedido = await Pedido.findById(req.params.id);
        if (!pedido) {
            return res.status(404).json({ mensaje: 'Pedido no encontrado' });
        }
        res.status(200).json({ pedido });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al obtener pedido', error: error.message });
    }
};

// Controlador para actualizar un pedido por su ID
exports.actualizarPedido = async (req, res) => {
    try {
        const pedido = await Pedido.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!pedido) {
            return res.status(404).json({ mensaje: 'Pedido no encontrado' });
        }
        res.status(200).json({ pedido });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al actualizar pedido', error: error.message });
    }
};

// Controlador para eliminar un pedido por su ID
exports.eliminarPedido = async (req, res) => {
    try {
        const pedido = await Pedido.findByIdAndDelete(req.params.id);
        if (!pedido) {
            return res.status(404).json({ mensaje: 'Pedido no encontrado' });
        }
        res.status(200).json({ mensaje: 'Pedido eliminado correctamente' });
    } catch (error) {
        res.status(500).json({ mensaje: 'Error al eliminar pedido', error: error.message });
    }
};

// Otros controladores para operaciones CRUD adicionales...
