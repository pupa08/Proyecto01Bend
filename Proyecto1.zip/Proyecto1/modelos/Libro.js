const mongoose = require('mongoose');

const libroEsquema = new mongoose.Schema({
    titulo: { type: String, required: true },
    autor: { type: String, required: true },
    genero: { type: String },
    fechaPublicacion: { type: Date },
    casaEditorial: { type: String },
    estado: { type: String, enum: ['nuevo', 'usado'], default: 'usado' },
    precio: { type: Number }
});

const Libro = mongoose.model('Libro', libroEsquema);

module.exports = Libro;
