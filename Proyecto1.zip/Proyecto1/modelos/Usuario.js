const mongoose = require('mongoose');

const usuarioEsquema = new mongoose.Schema({
    nombre: { type: String, required: true },
    correo: { type: String, required: true, unique: true },
    contraseña: { type: String, required: true },
    direccion: { type: String }
});

const Usuario = mongoose.model('Usuario', usuarioEsquema);

module.exports = Usuario;
