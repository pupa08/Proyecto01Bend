const mongoose = require('mongoose');

const pedidoEsquema = new mongoose.Schema({
    usuarioQueRealiza: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
    usuarioQueRecibe: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
    libros: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Libro', required: true }],
    estado: { type: String, enum: ['en progreso', 'completado', 'cancelado'], default: 'en progreso' },
    fechaCreacion: { type: Date, default: Date.now }
});

const Pedido = mongoose.model('Pedido', pedidoEsquema);

module.exports = Pedido;
